#!/usr/bin/python3
import argparse
import xml.etree.ElementTree as ET
import re
import zipfile
import shutil

def column_to_int(column):
    result = 0

    column = column.upper()

    for char_count in range(len(column)):
        if len(column) - (char_count + 1) > 0:
            result = result + (ord(column[char_count]) - 64)* (26 ** (len(column) - (char_count + 1)))
        else:
            result = result + (ord(column[char_count]) - 64)

    return result

def delete_temp_folder(temp_folder):
    try:
        shutil.rmtree(temp_folder)
    except:
        print('[Error]')
        raise

def extract_CALL(formula):
    return formula.upper().replace('CALL(', '').replace(')', '')

def extract_cell_s(cell):
    result = 'invalid'

    for c in _xmlRoot.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        if c.attrib['r'] == cell:
            result = c.attrib['s']

    return result

def extract_CHAR(formula):
    return formula.upper().replace('CHAR(', '').replace(')', '').replace('$', '')

def extract_column(cell):
    result = 'invalid'
    colume_regex = re.compile('[a-zA-Z]+')
    column = colume_regex.findall(cell)
    if len(column) > 0:
        result = column[0]

    return result

def extract_formula(cell):
    result = 'invalid'

    for c in _xmlRoot.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        if c.attrib['r'] == cell:
            for f in c.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}f'):
                result = f.text

    if result == 'invalid' and cell in cells:
        result = cells[cell]

    return result

def extract_FORMULA(formula):
    result = formula.upper().replace('FORMULA(', '').replace(')', '').replace('$', '')
    result = result.split(',')
    return result[0]

def extract_FORMULA_output(formula):
    result = formula.upper().replace('FORMULA(', '').replace(')', '').replace('$', '')
    result = result.split(',')
    return result[1]

def extract_function_value(formula, function):
    function = function + '('
    result = formula.upper().replace(function, '')
    result = result[:-1]
    return result

def extract_macro_config(FILE_NAME_workbook, FILE_NAME_workbook_rels):
    auto_open_cell = ''
    spreadsheet_name = ''
    sheet_target = ''
    rId = ''

    tree = ET.parse(FILE_NAME_workbook)
    root = tree.getroot()

    for definedName in root.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}definedName'):
        if definedName.attrib['name'].startswith('_xlnm.Auto_Open'):
            strings = definedName.text.split('!')
            spreadsheet_name = strings[0]
            auto_open_cell = strings[1].replace('$', '')

            for sheet in root.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet'):
                if sheet.attrib['name'] == spreadsheet_name:
                    rId = sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
                    break
            break

    tree = ET.parse(FILE_NAME_workbook_rels)
    root = tree.getroot()

    for relationship in root.iter(tag='{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
        if relationship.attrib['Id'] == rId:
            sheet_target = relationship.attrib['Target']

    return sheet_target, auto_open_cell

def extract_row(cell):
    result = 0
    row_regex = re.compile('[0-9]+')
    row = row_regex.findall(cell)
    if len(row) > 0:
        result = row[0]

    return int(result)

def extract_row_info(in_row, info):
    result = 'invalid'

    if info == '17':
        information = 'ht'
    for row in _xmlRoot.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row'):
        if row.attrib['r'] == in_row:
            result = row.attrib[information]

    return result

def extract_RUN(formula):
    return formula.upper().replace('RUN(', '').replace(')', '').replace('$', '')

def extract_style(s, style):
    result = 'invalid'

    if style == '19':
        style_description = 'val'
    elif style == '24':
        style_description = 'rgb'
    elif style == '38':
        style_description = 'rgb'
    elif style == '50':
        style_description = 'vertical'

    xf_count = 0

    for cellXfs in _xmlRoot_style.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}cellXfs'):
        for xf in cellXfs.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}xf'):
            if xf_count == int(s):
                if style == '19':
                    font_style = xf.attrib['fontId']
                    for fonts in _xmlRoot_style.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}fonts'):
                        font_count = 0
                        for font in fonts.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}font'):
                            if font_count == int(font_style):
                                for sz in font.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sz'):
                                    result = sz.attrib[style_description]
                            font_count = font_count + 1
                elif style == '24':
                    result = '0'
                    font_style = xf.attrib['fontId']
                    for fonts in _xmlRoot_style.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}fonts'):
                        font_count = 0
                        for font in fonts.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}font'):
                            if font_count == int(font_style):
                                for color in font.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}color'):
                                    result = str(get_color_index(color.attrib[style_description]))
                            font_count = font_count + 1
                elif style == '38':
                    fill_style = xf.attrib['fillId']
                    for fills in _xmlRoot_style.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}fills'):
                        fill_count = 0
                        for fill in fills.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}fill'):
                            if fill_count == int(fill_style):
                                for fgColor in fill.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}fgColor'):
                                    result = str(get_color_index(fgColor.attrib[style_description]))
                            fill_count = fill_count + 1
                elif style == '50':
                    for alignment in xf.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}alignment'):
                        print('[extract_style] alignment.attrib[style_description] = ' + alignment.attrib[style_description])
                        result = alignment.attrib[style_description]
                        if result.upper() == 'TOP':
                            result = '1'
                        elif result.upper() == 'CENTER':
                            result = '2'
                        elif result.upper() == 'BOTTOM':
                            result = '3'
                        elif result.upper() == 'JUSTIFY':
                            result = '4'

            xf_count = xf_count + 1

    return result

def extract_value(cell):
    result = 'invalid'

    for c in _xmlRoot.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        if c.attrib['r'] == cell:
            for f in c.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v'):
                result = f.text

    if result == 'invalid' and cell in cells:
        result = cells[cell]

    return str(result)

def function_FORMULA_FILL(formula, cell):
    result = 'invalid'
    formula_text = extract_function_value(formula, 'FORMULA.FILL')

    value_updated = formula_text

    column_regex = re.compile('[a-zA-Z]{1,3}\d+')
    column_result = column_regex.findall(formula_text)
    for column in column_result:
        new_value = extract_value(column)
        if new_value != 'invalid':
            value_updated = value_updated.replace(column, new_value)
        elif column in cells:
            value_updated = value_updated.replace(column, str(cells[column]))

    char_regex = re.compile('CHAR\(.*?\)')
    char_result = char_regex.findall(value_updated)

    for char_function in char_result:
        char_value = extract_function_value(char_function, 'CHAR')
        new_value = round(eval(char_value))
        value_updated = value_updated.replace(char_function, chr(new_value))

    value_updated = value_updated.replace('&', '')

    reference = column_regex.findall(formula_text)[-1]

    RC_regex = re.compile('R\[[-]?\d+\]C\[[-]?\d+\]')
    RC_regex_result = RC_regex.findall(value_updated)

    reference_column = extract_column(reference)
    reference_row = extract_row(reference)

    for RC in RC_regex_result:
        RC_R = re.search('R\[[-]?\d+\]', RC)
        RC_R_no = RC_R.group(0).replace('R[', '').replace(']','')
        RC_C = re.search('C\[[-]?\d+\]', RC)
        RC_C_no = RC_C.group(0).replace('C[', '').replace(']','')

        new_row = int(reference_row) + int(RC_R_no)
        new_column = int_to_column(column_to_int(reference_column) + int(RC_C_no))
        new_cell = new_column + str(new_row)

        new_cell_value = extract_value(new_cell)
        if new_cell_value.startswith('='):
            new_cell_value = new_cell_value[1:]

        value_updated = value_updated.replace(RC, new_cell_value).replace('""','')

    print('[FORMULA.FILL] cell = ' + cell + ' formula = FORMULA.FILL(' + value_updated + ')')

    value_updated = value_updated.replace(',' + reference, '')
    cells[reference] = value_updated

def function_GET_CELL(formula):
    result = 'invalid'
    value = extract_function_value(formula, 'GET.CELL')
    values = value.split(',')
    type_num = values[0]
    reference = values[1]

    extracted_result = 'invalid'

    if type_num == '17':
        result = extract_row_info(str(extract_row(reference)), type_num)
    elif type_num == '19' or type_num == '24' or type_num == '38' or type_num == '50':
        result = extract_style(extract_cell_s(reference), type_num)
        if result == 'invalid' and reference in cells:
            result = cells[reference]

    return result

def function_SET_VALUE(formula, cell):
    code = extract_function_value(formula, 'SET.VALUE')
    codes = code.split(', ')

    reference = codes[0]
    value = codes[1]
    value_calculated = 0

    value = value.upper()
    value_updated = value

    get_cell_regex = re.compile('GET\.CELL\(.*?\)')
    result = get_cell_regex.findall(value)

    if len(result) > 0:
        for get_cell in result:
            extracted_result = function_GET_CELL(get_cell)
            if extracted_result != 'invalid':
                value_updated = value_updated.replace(get_cell, extracted_result)
        value_calculated = eval(value_updated)
        cells[reference] = value_calculated
    else:
        value_calculated = eval(value)
        cells[reference] = value_calculated

    print('[SET.VALUE] cell = ' + cell + ' formula = ' + formula)

def get_color_index(color):
    result = 0

    color_index = {
        1 : 'FF000000',
        2 : 'FFFFFFFF',
        3 : 'FFFF0000',
        4 : 'FF00FF00',
        5 : 'FF0000FF',
        6 : 'FFFFFF00',
        7 : 'FFFF00FF',
        8 : 'FF00FFFF',
        9 : 'FF800000',
        10 : 'FF008000',
        11 : 'FF000080',
        12 : 'FF808000',
        13 : 'FF800080',
        14 : 'FF008080',
        15 : 'FFC0C0C0',
        16 : 'FF808080',
        17 : 'FF9999FF',
        18 : 'FF993366',
        19 : 'FFFFFFCC',
        20 : 'FFCCFFFF',
        21 : 'FF660066',
        22 : 'FFFF8080',
        23 : 'FF0066CC',
        24 : 'FFCCCCFF',
        25 : 'FF000080',
        26 : 'FFFF00FF',
        27 : 'FFFFFF00',
        28 : 'FF00FFFF',
        29 : 'FF800080',
        30 : 'FF800000',
        31 : 'FF008080',
        32 : 'FF0000FF',
        33 : 'FF00CCFF',
        34 : 'FFCCFFFF',
        35 : 'FFCCFFCC',
        36 : 'FFFFFF99',
        37 : 'FF99CCFF',
        38 : 'FFFF99CC',
        39 : 'FFCC99FF',
        40 : 'FFFFCC99',
        41 : 'FF3366FF',
        42 : 'FF33CCCC',
        43 : 'FF99CC00',
        44 : 'FFFFCC00',
        45 : 'FFFF9900',
        46 : 'FFFF6600',
        47 : 'FF666699',
        48 : 'FF969696',
        49 : 'FF003366',
        50 : 'FF339966',
        51 : 'FF003300',
        52 : 'FF333300',
        53 : 'FF993300',
        54 : 'FF993366',
        55 : 'FF333399',
        56 : 'FF333333'
    }

    for key, value in color_index.items():
        if value == color:
            result = key
            break

    return result

def initialise(TARGET_FILE_NAME, STYLE_FILE_NAME):
    tree = ET.parse(TARGET_FILE_NAME)
    namespaces = {'': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
                  'xm': 'http://schemas.microsoft.com/office/excel/2006/main',
                  'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
                  'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
                  'x14ac': 'http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac'}

    for key in namespaces:
        ET.register_namespace(key, namespaces[key])

    global _xmlRoot
    _xmlRoot = tree.getroot()

    tree_style = ET.parse(STYLE_FILE_NAME)
    global _xmlRoot_style
    _xmlRoot_style = tree_style.getroot()

def int_to_column(number):
    result = ''
    number_updated = number

    for count in range(3, 0, -1):
        if number_updated > (26 ** count):
            divisor = number_updated // (26 ** count)
            result = result + chr(divisor + 64)
            number_updated = number_updated - (divisor * (26 ** count))
        if (count == 1) and (number_updated <= 26):
            result = result + chr(number_updated + 64)

    return result

def next_cell(cell):
    column = extract_column(cell)
    row = extract_row(cell)

    return column + str(row + 1)

def extract(FILE_NAME, auto_open_cell):

    row = extract_row(auto_open_cell)

    cell = auto_open_cell
    global cells
    cells = {}

    empty_cell_threshhold = 0
    while extract_row(cell) <= 1048576 and empty_cell_threshhold < 10000:
        formula = extract_formula(cell)
        if formula.upper().startswith('RUN'):
            while formula.upper().startswith('RUN'):
                print('[RUN] cell =', cell, 'formula =', formula)
                cell = extract_RUN(formula)
                formula = extract_formula(cell)

                if formula == 'invalid':
                    empty_cell_threshhold = 0

        elif formula.upper().startswith('CHAR'):
            calculation = extract_CHAR(formula)

            if calculation.find('-') > -1:
                split = calculation.split('-')
                value = int(extract_value(split[0])) - int(split[1])
            if calculation.find('+') > -1:
                split = calculation.split('+')
                value = int(extract_value(split[0])) + int(split[1])

            print('[CHAR] cell =', cell,'value =', value, 'char =', chr(value))
            cells[cell] = chr(value)

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('FORMULA('):
            string = extract_FORMULA(formula)
            output = extract_FORMULA_output(formula)
            strings = string.split('&')
            value = ''

            for item in strings:
                if extract_value(item) != 'invalid':
                    value = value + extract_value(item)
                elif item in cells:
                    value = value + cells[item]

            cells[output] = value

            print('[FORMULA] cell =', cell,'value =', value)

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('FORMULA.FILL('):
            function_FORMULA_FILL(formula, cell)

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('CALL'):
            code = extract_CALL(formula)
            codes = code.split(',')
            value = code
            for item in codes:
                if item != '' and item != '0':
                    if item.startswith('$'):
                        item_trimed = item.replace('$', '')
                        if extract_value(item_trimed) != 'invalid':
                            value = value.replace(item, extract_value(item_trimed))
                        elif item_trimed in cells:
                            value = value.replace(item, cells[item_trimed])

            print('[CALL] code = ' + code + ' cell = ' + cell + ' value = CALL(' + value + ')')

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('SET.VALUE'):
            function_SET_VALUE(formula, cell)

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('GOTO'):
            print('[GOTO] cell =', cell, 'formula =', formula)
            cell = extract_function_value(formula, 'GOTO')

            empty_cell_threshhold = 0
        else:
            if formula != 'invalid':
                print('[ELSE] cell =', cell, 'formula =', formula)
                if formula.upper() == "HALT()":
                    break
            cell = next_cell(cell)
            empty_cell_threshhold = empty_cell_threshhold + 1

def unzip(FILE_NAME, temp_folder):
    with zipfile.ZipFile(FILE_NAME, 'r') as zip_ref:
        zip_ref.extractall(temp_folder)

def main():

    argparser = argparse.ArgumentParser()
    argparser.add_argument("FILE_NAME")
    args = argparser.parse_args()
    temp_folder = args.FILE_NAME + '_temp'

    unzip(args.FILE_NAME, temp_folder)

    sheet_target, auto_open_cell = extract_macro_config('./' + temp_folder + '/xl/workbook.xml', './' + temp_folder + '/xl/_rels/workbook.xml.rels')
    target_full_file_path = './' + temp_folder + '/xl/' + sheet_target
    style_full_file_path = './' + temp_folder + '/xl/styles.xml'

    initialise(target_full_file_path, style_full_file_path)
    extract(target_full_file_path, auto_open_cell)
    delete_temp_folder(temp_folder)

if __name__ == "__main__":
    main()
