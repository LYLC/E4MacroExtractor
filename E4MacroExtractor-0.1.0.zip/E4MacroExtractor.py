#!/usr/bin/python3
import argparse
import xml.etree.ElementTree as ET
import re
import zipfile
import shutil

def unzip(FILE_NAME, temp_folder):
    with zipfile.ZipFile(FILE_NAME, 'r') as zip_ref:
        zip_ref.extractall(temp_folder)

def delete_temp_folder(temp_folder):
    try:
        shutil.rmtree(temp_folder)
    except:
        print('[Error]')
        raise

def extract_formula(root, cell):
    result = 'invalid'

    for c in root.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        if c.attrib['r'] == cell:
            for f in c.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}f'):
                result = f.text
    return result

def extract_value(root, cell):
    result = 'invalid'

    for c in root.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        if c.attrib['r'] == cell:
            for f in c.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v'):
                result = f.text
    return result

def extract_RUN(formula):
    return formula.upper().replace('RUN(', '').replace(')', '').replace('$', '')

def extract_CHAR(formula):
    return formula.upper().replace('CHAR(', '').replace(')', '').replace('$', '')

def extract_FORMULA(formula):
    result = formula.upper().replace('FORMULA(', '').replace(')', '').replace('$', '')
    result = result.split(',')
    return result[0]

def extract_FORMULA_output(formula):
    result = formula.upper().replace('FORMULA(', '').replace(')', '').replace('$', '')
    result = result.split(',')
    return result[1]

def extract_CALL(formula):
    return formula.upper().replace('CALL(', '').replace(')', '')

def extract_column(cell):
    result = 'invalid'
    colume_regex = re.compile('[a-zA-Z]+')
    column = colume_regex.findall(cell)
    if len(column) > 0:
        result = column[0]
    return result

def extract_row(cell):
    result = 0
    row_regex = re.compile('[0-9]+')
    row = row_regex.findall(cell)
    if len(row) > 0:
        result = row[0]
    return int(result)

def next_cell(cell):
    column = extract_column(cell)
    row = extract_row(cell)
    return column + str(row + 1)

def extract_macro_config(FILE_NAME_workbook, FILE_NAME_workbook_rels):
    auto_open_cell = ''
    spreadsheet_name = ''
    sheet_target = ''
    rId = ''

    tree = ET.parse(FILE_NAME_workbook)
    root = tree.getroot()

    for definedName in root.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}definedName'):
        if definedName.attrib['name'] == '_xlnm.Auto_Open':
            strings = definedName.text.split('!')
            spreadsheet_name = strings[0]
            auto_open_cell = strings[1].replace('$', '')

            for sheet in root.iter(tag='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet'):
                if sheet.attrib['name'] == spreadsheet_name:
                    rId = sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
                    break
            break

    tree = ET.parse(FILE_NAME_workbook_rels)
    root = tree.getroot()

    for relationship in root.iter(tag='{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
        if relationship.attrib['Id'] == rId:
            sheet_target = relationship.attrib['Target']

    return sheet_target, auto_open_cell

def extract(FILE_NAME, auto_open_cell):
    tree = ET.parse(FILE_NAME)
    namespaces = {'': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
                  'xm': 'http://schemas.microsoft.com/office/excel/2006/main',
                  'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
                  'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
                  'x14ac': 'http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac'}

    for key in namespaces:
        ET.register_namespace(key, namespaces[key])

    root = tree.getroot()

    row = extract_row(auto_open_cell)

    cell = auto_open_cell
    cells = {}

    empty_cell_threshhold = 0
    #Excel last row = 1048576
    while extract_row(cell) <= 1048576 and empty_cell_threshhold < 10000:
        formula = extract_formula(root, cell)
        if formula.upper().startswith('RUN'):
            while formula.upper().startswith('RUN'):
                print('[RUN] cell =', cell, 'formula =', formula)
                cell = extract_RUN(formula)
                formula = extract_formula(root, cell)

                if formula == 'invalid':
                    empty_cell_threshhold = 0

        elif formula.upper().startswith('CHAR'):
            calculation = extract_CHAR(formula)

            if calculation.find('-') > -1:
                split = calculation.split('-')
                value = int(extract_value(root, split[0])) - int(split[1])
            if calculation.find('+') > -1:
                split = calculation.split('+')
                value = int(extract_value(root, split[0])) + int(split[1])

            print('[CHAR] cell =', cell,'value =', value, 'char =', chr(value))
            cells[cell] = chr(value)

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('FORMULA'):
            string = extract_FORMULA(formula)
            output = extract_FORMULA_output(formula)
            strings = string.split('&')
            value = ''

            for item in strings:
                if extract_value(root, item) != 'invalid':
                    value = value + extract_value(root, item)
                elif item in cells:
                    value = value + cells[item]

            cells[output] = value

            print('[FORMULA] cell =', cell,'value =', value)

            cell = next_cell(cell)
            empty_cell_threshhold = 0

        elif formula.upper().startswith('CALL'):
            code = extract_CALL(formula)
            codes = code.split(',')
            value = code
            for item in codes:
                if item != '' and item != '0':
                    if item.startswith('$'):
                        item_trimed = item.replace('$', '')
                        if extract_value(root, item_trimed) != 'invalid':
                            value = value.replace(item, extract_value(root, item_trimed))
                        elif item_trimed in cells:
                            value = value.replace(item, cells[item_trimed])

            print('[CALL] code = ' + code + ' cell = ' + cell + ' value = CALL(' + value + ')')

            cell = next_cell(cell)
            empty_cell_threshhold = 0
        else:
            if formula != 'invalid':
                print('[ELSE] cell =', cell, 'formula =', formula)
            cell = next_cell(cell)
            empty_cell_threshhold = empty_cell_threshhold + 1

def main():
    argparser = argparse.ArgumentParser()
    argparser.add_argument("FILE_NAME")
    args = argparser.parse_args()
    temp_folder = args.FILE_NAME + '_temp'

    unzip(args.FILE_NAME, temp_folder)

    sheet_target, auto_open_cell = extract_macro_config('./' + temp_folder + '/xl/workbook.xml', './' + temp_folder + '/xl/_rels/workbook.xml.rels')
    extract('./' + temp_folder + '/xl/' + sheet_target, auto_open_cell)
    delete_temp_folder(temp_folder)

if __name__ == "__main__":
    main()
